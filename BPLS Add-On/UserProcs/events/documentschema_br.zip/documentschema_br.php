<?php
 
	include_once("./classes/usermsgs.php");


function onBeforeAddEventdocumentschema_brGPSBPLS($objTable) {
	global $page;
	global $objConnection;
	$actionReturn = true;
	switch ($objTable->dbtable) {
		case "u_bplapps":
			if ($objTable->docstatus=="Assessing") $objTable->setudfvalue("u_assessingdatetime",date('Y-m-d h:i:s'));
			if ($actionReturn && $objTable->docstatus=="Encoding" && $objTable->getudfvalue("u_preassbill")==1) {
				$actionReturn = onCustomEventcreatepreassbilldocumentschema_brGPSBPLS($objTable);
				if (!$actionReturn) $page->setitem("u_preassbill",0);
			}	
			if ($actionReturn) $actionReturn = onCustomEventupdatebplmddocumentschema_brGPSBPLS($objTable);
			break;
	}
	return $actionReturn;
}


/*
function onAddEventdocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	$actionReturn = true;
	switch ($objTable->dbtable) {
		case "u_cylindercustobs":
			break;
	}
	return $actionReturn;
}
*/


function onBeforeUpdateEventdocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	global  $page;
	$actionReturn = true;
	switch ($objTable->dbtable) {
		case "u_bplapps":
			if ($objTable->docstatus=="Assessing" && $objTable->docstatus!=$objTable->fields["DOCSTATUS"]) {
				$objTable->setudfvalue("u_assessingdatetime",date('Y-m-d h:i:s'));
			} elseif ($objTable->docstatus=="Assessed" && $objTable->docstatus!=$objTable->fields["DOCSTATUS"]) {
				$objTable->setudfvalue("u_assesseddatetime",date('Y-m-d h:i:s'));
				$objTable->setudfvalue("u_assessedby",$_SESSION["userid"]);
			} elseif ($objTable->docstatus=="Approved" && $objTable->docstatus!=$objTable->fields["DOCSTATUS"]) {
				$objTable->setudfvalue("u_approveddatetime",date('Y-m-d h:i:s'));
				$objTable->setudfvalue("u_approvedby",$_SESSION["userid"]);
			} elseif ($objTable->docstatus=="Disapproved" && $objTable->docstatus!=$objTable->fields["DOCSTATUS"]) {
				$objTable->setudfvalue("u_disapproveddatetime",date('Y-m-d h:i:s'));
			} elseif ($objTable->docstatus=="Printing" && $objTable->docstatus!=$objTable->fields["DOCSTATUS"]) {
				$objTable->setudfvalue("u_paiddatetime",date('Y-m-d h:i:s'));
			}	
			
			if (($objTable->docstatus=="Assessed" && $objTable->getudfvalue("u_approverremarks")!=$objTable->fields["U_APPROVERREMARKS"]) || 
				($objTable->docstatus=="Assessing" && ($objTable->fields["DOCSTATUS"]=="Approved" || $objTable->fields["DOCSTATUS"]=="Disapproved"))) {
				$msgid = date('Y-m-d H:i:s') . ".BPLApproverRemarks." . $objRs->fields["USERID"] . " " .$_SESSION["company"] . "-" . $_SESSION["branch"] . "-" . $_SERVER["REMOTE_ADDR"];
				//var_dump($objRs->fields["USERID"]);
				$objUserMsgs =  new usermsgs(null,$objConnection);
				$objUserMsgs->prepareadd();
				$objUserMsgs->msgid = $msgid;
				$objUserMsgs->userid = $objTable->getudfvalue("u_assessedby");
				$objUserMsgs->msgfrom = $_SESSION["userid"];
				$objUserMsgs->msgtype = "IBX";
				$objUserMsgs->msgsubtype = "RA";  
				$objUserMsgs->priority=1;
				$objUserMsgs->msgsubject = "Business permit approver remarks for application no. ".$objTable->docno."." ;
				$objUserMsgs->msgbody = $objTable->getudfvalue("u_approverremarks");
				$objUserMsgs->status = "U";
				$objUserMsgs->msgdate = date('Y-m-d');
				$objUserMsgs->msgtime = date('H:i:s');
				$actionReturn = $objUserMsgs->add();
				$objTable->docstatus="Assessing";
				if ($actionReturn && $objTable->fields["DOCSTATUS"]=="Approved") {
					$objLGUBills = new documentschema_br(null,$objConnection,"u_lgubills");
					if ($objLGUBills->getbysql("U_APPNO='".$objTable->docno."' AND U_PREASSBILL=0 AND U_MODULE='Business Permit'")) {
						$actionReturn = $objLGUBills->executesql("DELETE FROM U_LGUBILLITEMS WHERE COMPANY='$objLGUBills->company' AND BRANCH='$objLGUBills->branch' AND DOCID='$objLGUBills->docid'",true);
						if ($actionReturn) $actionReturn = $objLGUBills->delete();
					} else {
						$page->docstatus=$objTable->fields["DOCSTATUS"];
						return raiseError("Unable to find Bill Document to remove.");
					}	

				}
			}	
			if ($actionReturn && $objTable->docstatus=="Encoding" && $objTable->fields["U_PREASSBILL"]==0 && $objTable->getudfvalue("u_preassbill")==1) {
				$actionReturn = onCustomEventcreatepreassbilldocumentschema_brGPSBPLS($objTable);
				if (!$actionReturn) $page->setitem("u_preassbill",0);
			}	
			if ($actionReturn) {
				$actionReturn = onCustomEventupdatebplmddocumentschema_brGPSBPLS($objTable,true);
				if ($objTable->docstatus=="Approved" && $objTable->fields["DOCSTATUS"]=="Assessed") {
					if ($objTable->getudfvalue("u_decisiondate")=="") $objTable->setudfvalue("u_decisiondate",currentdateDB());
					$actionReturn = onCustomEventcreatebilldocumentschema_brGPSBPLS($objTable);
				} elseif ($objTable->docstatus=="Disapproved" && $objTable->fields["DOCSTATUS"]=="Assessed") {
					if ($objTable->getudfvalue("u_decisiondate")=="") $objTable->setudfvalue("u_decisiondate",currentdateDB());
				}	
			}	
			break;
	}
	return $actionReturn;
}

function onCustomEventcreatepreassbilldocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	$actionReturn = true;
	
	$objRs = new recordset (NULL,$objConnection);
	$objLGUBills = new documentschema_br(null,$objConnection,"u_lgubills");
	$objLGUBillItems = new documentlinesschema_br(null,$objConnection,"u_lgubillitems");

	$objRs_uLGUSetup = new recordset(null,$objConnection);
	$objRs_uLGUSetup->queryopen("select A.U_BPLDUEDAY from U_LGUSETUP A");
	if (!$objRs_uLGUSetup->queryfetchrow("NAME")) {
		return raiseError("No setup found for business permit due day.");
	}	

	$objLGUBills->prepareadd();
	$objLGUBills->docno = getNextNoByBranch("u_lgubills","",$objConnection);
	$objLGUBills->docid = getNextIdByBranch("u_lgubills",$objConnection);
	$objLGUBills->docstatus = "O";
	$objLGUBills->setudfvalue("u_profitcenter","BPL");
	$objLGUBills->setudfvalue("u_module","Business Permit");
	$objLGUBills->setudfvalue("u_paymode","A");
	$objLGUBills->setudfvalue("u_preassbill",1);
	$objLGUBills->setudfvalue("u_appno",$objTable->docno);
	if ($objTable->getudfvalue("u_apptype")=="NEW") $objLGUBills->setudfvalue("u_custno",$objTable->docno);
	elseif ($objTable->getudfvalue("u_bpno")!="") $objLGUBills->setudfvalue("u_custno",$objTable->getudfvalue("u_bpno"));
	else $objLGUBills->setudfvalue("u_custno",$objTable->docno);
	$objLGUBills->setudfvalue("u_custname",$objTable->getudfvalue("u_businessname"));
	$objLGUBills->setudfvalue("u_docdate",$objTable->getudfvalue("u_appdate"));
	$startdate = getmonthstartDB($objTable->getudfvalue("u_appdate"));
	$objLGUBills->setudfvalue("u_duedate",dateadd("d",$objRs_uLGUSetup->fields["U_BPLDUEDAY"]-1,$startdate));
//	$objLGUBills->setudfvalue("u_duedate",$objTable->getudfvalue("u_appdate"));
	$objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - ".date('Y') );
	$totalamount=0;

	$objRs->queryopen("SELECT A.U_REQDESC, A.U_FEECODE, A.U_FEEDESC, A.U_AMOUNT FROM U_BPLAPPREQ2S A LEFT JOIN U_LGUFEES B ON B.CODE=A.U_FEECODE where A.COMPANY='".$_SESSION["company"]."' AND A.BRANCH='".$_SESSION["branch"]."' AND A.DOCID='$objTable->docid' AND  A.U_AMOUNT>0");
	while ($objRs->queryfetchrow("NAME")) {
		if ($objRs->fields["U_FEECODE"]=="") {
			return raiseError("Fee Code must define for Requirement [".$objRs->fields["U_REQDESC"]."].");
		}
		//var_dump($objRs->fields);
		$objLGUBillItems->prepareadd();
		$objLGUBillItems->docid = $objLGUBills->docid;
		$objLGUBillItems->lineid = getNextIdByBranch("u_lgubillitems",$objConnection);
		$objLGUBillItems->setudfvalue("u_itemcode",$objRs->fields["U_FEECODE"]);
		$objLGUBillItems->setudfvalue("u_itemdesc",$objRs->fields["U_FEEDESC"]);
		$objLGUBillItems->setudfvalue("u_amount",$objRs->fields["U_AMOUNT"]);
		$totalamount+=$objRs->fields["U_AMOUNT"];
		$objLGUBillItems->privatedata["header"] = $objLGUBills;
		$actionReturn = $objLGUBillItems->add();
		if (!$actionReturn) break;
	}
	if ($actionReturn) {
		$objRs->queryopen("SELECT A.U_REQDESC, A.U_FEECODE, A.U_FEEDESC, A.U_AMOUNT FROM U_BPLAPPREQ3S A LEFT JOIN U_LGUFEES B ON B.CODE=A.U_FEECODE where A.COMPANY='".$_SESSION["company"]."' AND A.BRANCH='".$_SESSION["branch"]."' AND A.DOCID='$objTable->docid' AND  A.U_AMOUNT>0");
		while ($objRs->queryfetchrow("NAME")) {
			if ($objRs->fields["U_FEECODE"]=="") {
				return raiseError("Fee Code must define for Requirement [".$objRs->fields["U_REQDESC"]."].");
			}
			//var_dump($objRs->fields);
			$objLGUBillItems->prepareadd();
			$objLGUBillItems->docid = $objLGUBills->docid;
			$objLGUBillItems->lineid = getNextIdByBranch("u_lgubillitems",$objConnection);
			$objLGUBillItems->setudfvalue("u_itemcode",$objRs->fields["U_FEECODE"]);
			$objLGUBillItems->setudfvalue("u_itemdesc",$objRs->fields["U_FEEDESC"]);
			$objLGUBillItems->setudfvalue("u_amount",$objRs->fields["U_AMOUNT"]);
			$totalamount+=$objRs->fields["U_AMOUNT"];
			$objLGUBillItems->privatedata["header"] = $objLGUBills;
			$actionReturn = $objLGUBillItems->add();
			if (!$actionReturn) break;
		}
	}	
	if ($actionReturn) {
		$objLGUBills->setudfvalue("u_totalamount",$totalamount);
		$objLGUBills->setudfvalue("u_dueamount",$totalamount);
		$actionReturn = $objLGUBills->add();
	}
	//if ($actionReturn) $actionReturn = raiseError("onCustomEventcreatepreassbilldocumentschema_brGPSBPLS()");

	return $actionReturn;
}

function onCustomEventcreatebilldocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	$actionReturn = true;
	
	$objRs = new recordset (NULL,$objConnection);
	$objLGUBills = new documentschema_br(null,$objConnection,"u_lgubills");
	$objLGUBillItems = new documentlinesschema_br(null,$objConnection,"u_lgubillitems");

	$objRs_uLGUSetup = new recordset(null,$objConnection);
	$objRs_uLGUSetup->queryopen("select A.U_BPLDUEDAY from U_LGUSETUP A");
	if (!$objRs_uLGUSetup->queryfetchrow("NAME")) {
		return raiseError("No setup found for business permit due day.");
	}	

	$ctr=0;
	$div=1;
	if ($objTable->getudfvalue("u_paymode")=="S") $div=2;
	elseif ($objTable->getudfvalue("u_paymode")=="Q") $div=4;
	
	while (true) {
		$ctr++;
		$objLGUBills->prepareadd();
		$objLGUBills->docno = getNextNoByBranch("u_lgubills","",$objConnection);
		$objLGUBills->docid = getNextIdByBranch("u_lgubills",$objConnection);
		$objLGUBills->docstatus = "O";
		$objLGUBills->setudfvalue("u_profitcenter","BPL");
		$objLGUBills->setudfvalue("u_module","Business Permit");
		$objLGUBills->setudfvalue("u_paymode",$objTable->getudfvalue("u_paymode"));
		$objLGUBills->setudfvalue("u_appno",$objTable->docno);
		if ($objTable->getudfvalue("u_apptype")=="NEW") $objLGUBills->setudfvalue("u_custno",$objTable->docno);
		elseif ($objTable->getudfvalue("u_bpno")!="") $objLGUBills->setudfvalue("u_custno",$objTable->getudfvalue("u_bpno"));
		else $objLGUBills->setudfvalue("u_custno",$objTable->docno);
		$objLGUBills->setudfvalue("u_custname",$objTable->getudfvalue("u_businessname"));
		//if ($objTable->getudfvalue("u_apptype")=="RENEW") {
			switch ($ctr) {
				case 1:
					$objLGUBills->setudfvalue("u_docdate",date('Y')."-01-01");
					$startdate = getmonthstartDB(date('Y')."-01-01");
					$objLGUBills->setudfvalue("u_duedate",dateadd("d",$objRsu_LGUSetup->fields["U_BPLDUEDAY"]-1,$startdate));
					if ($objTable->getudfvalue("u_paymode")=="S") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - 1st Semi-Annual, ".date('Y') );
					elseif ($objTable->getudfvalue("u_paymode")=="Q") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - Q1, ".date('Y') );
					break;
				case 2:
					$objLGUBills->setudfvalue("u_docdate",date('Y')."-04-01");
					$startdate = getmonthstartDB(date('Y')."-04-01");
					$objLGUBills->setudfvalue("u_duedate",dateadd("d",$objRsu_LGUSetup->fields["U_BPLDUEDAY"]-1,$startdate));
					if ($objTable->getudfvalue("u_paymode")=="S") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - 2nd Semi-Annual, ".date('Y') );
					elseif ($objTable->getudfvalue("u_paymode")=="Q") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - Q2, ".date('Y') );
					break;
				case 3:
					$objLGUBills->setudfvalue("u_docdate",date('Y')."-07-01");
					$startdate = getmonthstartDB(date('Y')."-07-01");
					$objLGUBills->setudfvalue("u_duedate",dateadd("d",$objRsu_LGUSetup->fields["U_BPLDUEDAY"]-1,$startdate));
					if ($objTable->getudfvalue("u_paymode")=="Q") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - Q3, ".date('Y') );
					break;
				case 4:
					$objLGUBills->setudfvalue("u_docdate",date('Y')."-10-01");
					$startdate = getmonthstartDB(date('Y')."-10-01");
					$objLGUBills->setudfvalue("u_duedate",dateadd("d",$objRsu_LGUSetup->fields["U_BPLDUEDAY"]-1,$startdate));
					if ($objTable->getudfvalue("u_paymode")=="Q") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - Q4, ".date('Y') );
					break;
			}
		//} else {
		//	$objLGUBills->setudfvalue("u_docdate",$objTable->getudfvalue("u_decisiondate"));
		//	$objLGUBills->setudfvalue("u_duedate",dateadd("d",20,$objTable->getudfvalue("u_decisiondate")));
		//}			
		if ($objTable->getudfvalue("u_paymode")=="A") $objLGUBills->setudfvalue("u_remarks","Business Permit & Licensing - ".date('Y') );

		$objRs->queryopen("SELECT A.U_FEECODE, A.U_FEEDESC, A.U_AMOUNT, B.U_INSTALLMENT FROM U_BPLAPPFEES A INNER JOIN U_LGUFEES B ON B.CODE=A.U_FEECODE where A.COMPANY='".$_SESSION["company"]."' AND A.BRANCH='".$_SESSION["branch"]."' AND A.DOCID='$objTable->docid' AND  A.U_AMOUNT>0");
		$totalamount=0;
		while ($objRs->queryfetchrow("NAME")) {
			//var_dump($objRs->fields);
			if ($ctr>1 && $objRs->fields["U_INSTALLMENT"]==0) continue;
			$objLGUBillItems->prepareadd();
			$objLGUBillItems->docid = $objLGUBills->docid;
			$objLGUBillItems->lineid = getNextIdByBranch("u_lgubillitems",$objConnection);
			$objLGUBillItems->setudfvalue("u_itemcode",$objRs->fields["U_FEECODE"]);
			$objLGUBillItems->setudfvalue("u_itemdesc",$objRs->fields["U_FEEDESC"]);
			//if ($objTable->getudfvalue("u_paymode")=="S" && $ctr==2) {
			//	$objLGUBillItems->setudfvalue("u_amount",$objRs->fields["U_AMOUNT"] - round($objRs->fields["U_AMOUNT"]/$div,2)*($ctr-1));
			//} elseif ($objTable->getudfvalue("u_paymode")=="Q" && $ctr==4) {
			//	$objLGUBillItems->setudfvalue("u_amount",$objRs->fields["U_AMOUNT"] - round($objRs->fields["U_AMOUNT"]/$div,2)*($ctr-1));
		//	} else {
				if ($objRs->fields["U_INSTALLMENT"]==0) {
					$objLGUBillItems->setudfvalue("u_amount",$objRs->fields["U_AMOUNT"]);
					$totalamount+=$objRs->fields["U_AMOUNT"];
				} else {
					$objLGUBillItems->setudfvalue("u_amount",round($objRs->fields["U_AMOUNT"]/$div,2));
					$totalamount+=round($objRs->fields["U_AMOUNT"]/$div,2);
				}	
			//}	
			$objLGUBillItems->privatedata["header"] = $objLGUBills;
			$actionReturn = $objLGUBillItems->add();
			if (!$actionReturn) break;
		}
		if ($actionReturn) {
			$objLGUBills->setudfvalue("u_totalamount",$totalamount);
			$objLGUBills->setudfvalue("u_dueamount",$totalamount);
			$actionReturn = $objLGUBills->add();
		}
		if (!$actionReturn) break;
		if ($objTable->getudfvalue("u_paymode")=="A" && $ctr==1) break;
		elseif ($objTable->getudfvalue("u_paymode")=="S" && $ctr==2) break;
		elseif ($objTable->getudfvalue("u_paymode")=="Q" && $ctr==4) break;
	}	
	//if ($actionReturn) $actionReturn = raiseError("onCustomEventupdatebplmddocumentschema_brGPSBPLS()");

	return $actionReturn;
}

function onCustomEventupdatebplmddocumentschema_brGPSBPLS($objTable,$edit=false) {
	global $objConnection;
	$actionReturn = true;
	
	$objRs = new recordset (NULL,$objConnection);
	$objBPLMDs = new masterdataschema_br(null,$objConnection,"u_bplmds");

	$objTable->setudfvalue("u_expdate", substr($objTable->getudfvalue("u_appdate"),0,4)."-12-31");
	$objTable->setudfvalue("u_year", substr($objTable->getudfvalue("u_appdate"),0,4));

	if (!$edit) $actionReturn = $objBPLMDs->getbysql("NAME='".addslashes($objTable->getudfvalue("u_businessname"))."'",0);
	else $actionReturn = $objBPLMDs->getbysql("NAME='".addslashes($objTable->fields["U_BUSINESSNAME"])."'",0);
	
	if ($actionReturn && $objTable->rowstat=="N" && $objTable->getudfvalue("u_apptype")=="NEW") {
		return raiseError("Business Name [".$objTable->getudfvalue("u_businessname")."] is already registered. Select Renew instead.");
	}
	if (!$actionReturn) { 
		$objBPLMDs->prepareadd();
		$objBPLMDs->code = $objTable->docno;
	}
	
	
	$objBPLMDs->name = $objTable->getudfvalue("u_businessname");
	$objBPLMDs->setudfvalue("u_tradename", $objTable->getudfvalue("u_tradename"));
	$objBPLMDs->setudfvalue("u_lastname", $objTable->getudfvalue("u_lastname"));
	$objBPLMDs->setudfvalue("u_firstname", $objTable->getudfvalue("u_firstname"));
	$objBPLMDs->setudfvalue("u_middlename", $objTable->getudfvalue("u_middlename"));
	$objBPLMDs->setudfvalue("u_apprefno", $objTable->docno);
	$objBPLMDs->setudfvalue("u_appdate", $objTable->getudfvalue("u_appdate"));
	$objBPLMDs->setudfvalue("u_expdate", $objTable->getudfvalue("u_expdate"));
	$objBPLMDs->setudfvalue("u_year", $objTable->getudfvalue("u_year"));
	if ($objTable->docstatus=="Approved" && $objTable->docstatus!=$objTable->fields["DOCSTATUS"]) {
		$objBPLMDs->setudfvalue("u_regdate",currentdateDB());
	}	
	if ($objTable->getudfvalue("u_firstyear")=="") {
		$objBPLMDs->setudfvalue("u_firstyear",date('Y'));
	}

	if ($objBPLMDs->getudfvalue("u_firstyear")==$objTable->getudfvalue("u_year") && $objTable->getudfvalue("u_apptype")!="NEW") {
		$objBPLMDs->setudfvalue("u_firstyear",$objTable->getudfvalue("u_year")-1);
	}
	if ($objBPLMDs->getudfvalue("u_firstyear")!=$objTable->getudfvalue("u_year") && $objTable->getudfvalue("u_apptype")=="NEW") {
		$objBPLMDs->setudfvalue("u_firstyear",$objTable->getudfvalue("u_year"));
	}

	if ($objBPLMDs->rowstat=="N") $actionReturn = $objBPLMDs->add();
	else $actionReturn = $objBPLMDs->update($objBPLMDs->code,$objBPLMDs->rcdversion);
	//if ($actionReturn) $actionReturn = raiseError("onCustomEventupdatebplmddocumentschema_brGPSBPLS()");
	return $actionReturn;
}

/*
function onUpdateEventdocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	$actionReturn = true;
	switch ($objTable->dbtable) {
		case "u_cylindercustobs":
			break;
	}
	return $actionReturn;
}
*/

/*
function onBeforeDeleteEventdocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	$actionReturn = true;
	switch ($objTable->dbtable) {
		case "u_cylindercustobs":
			break;
	}
	return $actionReturn;
}
*/

/*
function onDeleteEventdocumentschema_brGPSBPLS($objTable) {
	global $objConnection;
	$actionReturn = true;
	switch ($objTable->dbtable) {
		case "u_cylindercustobs":
			break;
	}
	return $actionReturn;
}
*/

?> 

