<SCRIPT language=JavaScript src="cfls/masterdata.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="cfls/document.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="ajax/xmlvalidatemasterdata.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="ajax/xmlvalidatedocument.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="ajax/xmlvalidatewtaxes.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="lnkbtns/documents.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="lnkbtns/journalentries.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="lnkbtns/journalvouchers.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="ajax/xmlformatdocnum.js" type=text/javascript></SCRIPT>
<SCRIPT language=JavaScript src="js/lnkbtncommon.js"></SCRIPT>